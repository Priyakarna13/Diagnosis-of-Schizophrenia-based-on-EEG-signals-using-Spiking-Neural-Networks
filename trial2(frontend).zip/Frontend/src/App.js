import React from "react";
import "./index.css";
import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import PrivateRoute from "./utils/PrivateRoute";
import { AuthProvider } from "./context/AuthContext";
import Home from "./views/homePage";
import Login from "./views/loginPage";
import Register from "./views/registerPage.js";
import PredictingPage from "./views/PredictingPage";
import AboutPage from "./views/AboutPage";
import axios from 'axios';
import Upload from "./components/runPy";
import ERPPage from "./views/ERPPage";
import plotpage from "./views/plotpage";

class App extends React.Component {
  
    state = {
        details: [],
        user: "",
        token:"",
    };
  
    componentDidMount() {
        let data;
  
        axios
            .get("http://localhost:8000/api/register")
            .then((res) => {
                data = res.data;
                this.setState({
                    details: data,
                });
            })
            .catch((err) => {});
    }
  
    renderSwitch = (param) => {
        switch (param + 1) {
            case 1:
                return "primary ";
            case 2:
                return "secondary";
            case 3:
                return "success";
            case 4:
                return "danger";
            case 5:
                return "warning";
            case 6:
                return "info";
            default:
                return "yellow";
        }
    };
  
    handleInput = (e) => {
        this.setState({
            [e.target.name]: e.target.value,
        });
    };
  
    handleSubmit = (e) => {
        e.preventDefault();
  
        axios
            .post("http://localhost:8000/admin/auth/user/", {
                name: this.state.user,
                token: this.state.token,
            })
            .then((res) => {
                this.setState({
                    user: "",
                    token: "",
                });
            })
            .catch((err) => {});
    };
    render() {
      return (
        <Router>
          <div className="flex flex-col min-h-screen overflow-auto">
            <AuthProvider>
              <Navbar />
              <Switch>
                <PrivateRoute component={PredictingPage} exact path="/predict" />
                <PrivateRoute component={ERPPage} exact path="/erp" />
                <Route component={Login} exact path="/login" />
                <Route component={Register} exact path="/register" />
                <Route component={Home} exact path="/" />
                <Route component={AboutPage} exact path="/about" />
                <Route component={plotpage} exact path="/plot" />
              </Switch>
            </AuthProvider>
          </div>
        </Router>
      );
      }
    }
export default App;