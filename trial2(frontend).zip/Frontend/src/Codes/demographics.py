import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import torch.nn.functional as F

df = pd.read_csv("demographic.csv")

df = df[df['subject'] != 1]
df = df[df['subject'] != 6]
df = df[df['subject'] != 16]
df = df[df['subject'] != 27]
print(df.head)

# Preprocess the data
# Convert categorical variable to numerical using LabelEncoder
le = LabelEncoder()
df[' gender'] = le.fit_transform(df[' gender'])

# Scale the numerical features using StandardScaler
scaler = StandardScaler()
df[[' age', ' education']] = scaler.fit_transform(df[[' age', ' education']])

# Separate the data into schizophrenia and non-schizophrenia groups
df_schizophrenia = df[df[' group'] == 1]
df_non_schizophrenia = df[df[' group'] == 0]

# Create the input and output data for the ANN model
# The input data consists of the age and education features
# The output data consists of a binary variable indicating schizophrenia diagnosis
X = df[[' age', ' education', ' gender']].to_numpy()
y = df[' group'].to_numpy()
device = "cuda"
X = torch.from_numpy(X).to(torch.float32).to(device)
y = torch.from_numpy(y).to(torch.float32).to(device)
# y = torch.reshape(y,(77,1))

y = F.one_hot(y.to(torch.int64), num_classes=2)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle = True)
print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)

class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(3,3) 
        self.fc2 = nn.Linear(3,3)
        self.fc3 = nn.Linear(3,2)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x
    
    
    
    
def train(data_x, data_y, learning_rate, n_epochs):

    device = "cuda"
    print(f"Using {device} device")
    model = Net().to(device)
    print("MODEL:", model)

    loss_function = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    losses = []
    for epoch in range(n_epochs):
        correct, accuracy = 0, 0
        pred_y = model(data_x)
        # print(pred_y, data_y)
        loss = loss_function(pred_y, data_y)
        losses.append(loss.item())

        model.zero_grad()
        loss.backward()
        optimizer.step()
            
        # _, predicted = torch.max(pred_y.data, 1)
        # print(pred_y.argmax(dim=1), data_y.argmax(dim=1))
        correct += (pred_y.argmax(dim=1) == data_y.argmax(dim=1)).float().sum()

        print("\nEpoch:", epoch)
        accuracy = 100 * correct / len(data_y)
        print("Accuracy = {}".format(accuracy))
        print("Loss = ", loss.item())

        if epoch%10 == 0:
            learning_rate = learning_rate/0.01
        
        return model, losses
        
print(X_train.shape, y_train.shape)

model1, losses1 = train(X_train, y_train.float(), 0.01, 200)    
plt.plot(losses1)
plt.ylabel('loss')
plt.xlabel('epoch')
plt.title("Learning rate %f"%(0.01))
plt.show()