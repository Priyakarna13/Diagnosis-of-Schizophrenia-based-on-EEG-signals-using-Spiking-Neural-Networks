// Your React.js component
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ChildComponent from './ChildComp';

const ScriptOutput1 = () => {
  const [output, setOutput] = useState('');
  const [showOutput, setShowOutput] = useState(false);

  const runScript = async () => {
    try {
      const response = await axios.get('http://localhost:8000/run-script-erp/');
      setOutput(response.data.output);
      setShowOutput(true);
      window.location.reload();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
        {showOutput ? (
        <div class="spinner-border">
        <pre>{output}</pre>
        </div>
      ) : (
        <button type="button" class="btn btn-primary" onClick={runScript}>Visualise</button>
      )}
    </div>
  );
};

export default ScriptOutput1;