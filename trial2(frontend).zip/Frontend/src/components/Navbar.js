import { useContext } from "react";
import { Link } from "react-router-dom";
import AuthContext from "../context/AuthContext";
import 'bootstrap/dist/css/bootstrap.css'
import { Button } from "bootstrap";
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';

function Navbar1() {
    const { user, logoutUser } = useContext(AuthContext);
    return (
      <>
      {[false].map((expand) => (
        <Navbar key={expand} bg="Dark" variant="dark" expand={expand} className="mb-3">
          <Container fluid>
            <Navbar.Brand href="/">Home</Navbar.Brand>
            <Navbar.Toggle style={{color: "white"}} aria-controls={`offcanvasNavbar-expand-${expand}`} />
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
              placement="end"
            >
              <Offcanvas.Header closeButton>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                  Diagnosis of Schizophrenia using Spiked Neural Network
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <Nav className="justify-content-end flex-grow-1 pe-3">
                  <Nav.Link href="/">Home</Nav.Link>
                  <Nav.Link href="about">About</Nav.Link>
                  {user ? (
                  <>
                    <Nav.Link href="/predict">ERP Time Series Prediction</Nav.Link>
                    <Nav.Link href="/erp">ERP Components Prediction</Nav.Link>
                    <Nav.Link href="/plot">ERP Time series visualisation</Nav.Link>
                  </>
                  ):(
                  <>
                  </>
                  )}</Nav>
                  <Nav>
                  {user ? (
                  <>
                    <NavDropdown title="Account" id="basic-nav-dropdown">
                    <NavDropdown.Item>Signed is as {user.username}</NavDropdown.Item>
                    <NavDropdown.Item>
                    <button class="btn btn-primary" onClick={logoutUser}>Logout</button>
                    </NavDropdown.Item>
                    </NavDropdown>
                  </> 
                  ):(
                  <>
                    <Nav.Link href="/login">Login</Nav.Link>
                    <Nav.Link href="/register">Register</Nav.Link>
                  </>)}
                </Nav>
              </Offcanvas.Body>
            </Navbar.Offcanvas>
          </Container>
        </Navbar>
      ))}
    </>
  );
}
  
  export default Navbar1;
  