export const variables={
    API_URL:"http://localhost:8000/",
    DEMO_URL:"http://localhost:8000/Upload/"
}