import React from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import { variables } from './variables';
import ScriptOutput1 from './PythExec2';
import ScriptOutput2 from './PythExec3';

const Upload = () => {
 
  return (
    <Container>
      <CardGroup>
      <Card>
        <Card.Body>
          <Card.Title>Prediction</Card.Title>
          <Card.Text>
            Get the prediction results below!
          </Card.Text>
        </Card.Body> 
        <Card.Footer>
          <ScriptOutput2></ScriptOutput2>
        </Card.Footer>
      </Card>
      </CardGroup>
    </Container>
  );
}

export default Upload;

