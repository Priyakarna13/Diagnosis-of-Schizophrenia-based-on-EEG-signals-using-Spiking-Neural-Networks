import React from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import { variables } from './variables';
import ScriptOutput1 from './PythExec2';
import ScriptOutput2 from './PythExec3';

const Upload1 = () => {
 
  return (
    <Container>
      <CardGroup>
        <Card>
            <Card.Body>
                <Card.Title>Plot</Card.Title>
                    <Card.Text>
                    Visualise the plot here!
                    </Card.Text>
            </Card.Body>
            <Card.Footer>
              <ScriptOutput1></ScriptOutput1>
            </Card.Footer>
      </Card>
      </CardGroup>
    </Container>
  );
}

export default Upload1;

