import React from "react";
import {Box, FooterLink} from "./FooterStyles"

const Footer = () => {
	return (
		<Box>
		<div class="container">
  			<footer>
    			<ul class="nav justify-content-center border-bottom">
					<li class="nav-item"><a href="/about" class="nav-link px-3 text-muted"><FooterLink>About Us</FooterLink></a></li>
      				<li class="nav-item"><a href="/" class="nav-link px-3 text-muted"><FooterLink>Home</FooterLink></a></li>
      				<li class="nav-item"><a href="/predict" class="nav-link px-3 text-muted"><FooterLink>Predict</FooterLink></a></li>
    			</ul>
    			<p color= "white" class="text-center text-muted">&copy; A students of the Dept. of AIML, BMSIT&M Initiative</p>
  			</footer>
		</div>
		</Box>
  );
};

export default Footer;