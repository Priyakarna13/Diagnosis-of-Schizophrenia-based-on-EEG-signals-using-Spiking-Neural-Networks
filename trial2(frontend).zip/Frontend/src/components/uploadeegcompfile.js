import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import React,{Component} from 'react';
import "./uploadcss.css"
import CardGroup from 'react-bootstrap/CardGroup';
import { useContext } from "react";
import AuthContext from "../context/AuthContext";
import { variables } from './variables';

class App2 extends Component {
  
  constructor(props){
    super(props);

    this.state={
        EFileId:0,
        EFileName:"EEG_Data.csv",
        EFilePath:variables.DEMO_URL
    }
}
  state = {
  
      // Initially, no file is selected
      selectedFile: null
    };
     
    // On file select (from the pop up)
    onFileChange = event => {
     
      // Update the state
      this.setState({ selectedFile: event.target.files[0] });
     
    };
     
    // On file upload (click the upload button)
    onFileUpload = () => {
      
      // Create an object of formData
      const formData = new FormData();
     
      // Update the formData object
      formData.append(
        "myFile",
        this.state.selectedFile,
        this.state.selectedFile.name
      );
     
      // Details of the uploaded file
      console.log(this.state.selectedFile);
     
      // Request made to the backend api
      // Send formData object
      axios.post("eeg/", formData);
      
    };
    DemoUpload=(event)=>{

      const formData=new FormData();
      formData.append("file",event.target.files[0],event.target.files[0].name);

      fetch(variables.API_URL+"demodata/savefile",{
          method:'POST',
          body:formData
      })
      .then(res=>res.json())
      .then(data=>{
          this.setState({DFileName:data});
      })
      if (formData.status === 201) {
        alert("Error");
      } else {
        alert("Uploaded EEG_Component file successfully");
      }
  }
    // File content to be displayed after
    // file upload is complete
    fileData = () => {
     
      if (this.state.selectedFile) {
          
        return (
          <div>
            <h2>File Details:</h2>
            <p>File Name: {this.state.selectedFile.name}</p>
  
            <p>File Type: {this.state.selectedFile.type}</p>
  
            <p>
              Last Modified:{" "}
              {this.state.selectedFile.lastModifiedDate.toDateString()}
            </p>
  
          </div>
        );
      } else {
        return (
          <div>
            <h6>Choose and upload your EEG time series data file (.csv) (Status : Not selected)</h6>
          </div>
          
        );
      }
    };
    
    render() {
      return (
            <CardGroup>
            <Card border="light" style={{ width: '18rem' }}>
                <Card.Body>
                    <Card.Title>Upload your EEG_Components file below</Card.Title>
                        <Card.Text>
                        (Make sure to name it 'EEG_Components.csv'){''}
                        </Card.Text>
                        {this.fileData()}
                        <Card.Footer>
                        <label class="label">
                            <input type="file" onInput={this.onFileChange} onChange={this.DemoUpload} />
                            <span>Upload Here</span>
                          </label>           
                        </Card.Footer>
              </Card.Body>
            </Card>
            </CardGroup>
      );
    }
  }
  
  export default App2;