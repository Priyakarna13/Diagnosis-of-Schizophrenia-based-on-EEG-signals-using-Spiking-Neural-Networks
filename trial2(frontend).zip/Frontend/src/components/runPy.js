import React from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import { variables } from './variables';
import ScriptOutput from './PythExec1';

const Upload = () => {
  
  return (
    <Container>
        <Card>
            <Card.Body>
                <Card.Title>Predict</Card.Title>
                    <Card.Text>
                    Get the prediction results below!
                    </Card.Text>
            </Card.Body>
            <Card.Footer>
            <ScriptOutput></ScriptOutput>
            </Card.Footer>
      </Card>
    </Container>
  );
}

export default Upload;

