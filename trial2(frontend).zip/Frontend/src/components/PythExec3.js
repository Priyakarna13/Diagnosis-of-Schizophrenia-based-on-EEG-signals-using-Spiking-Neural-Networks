// Your React.js component
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ChildComponent from './ChildComp';

const ScriptOutput2 = () => {
  const [output, setOutput] = useState('');
  const [showOutput, setShowOutput] = useState(false);

  const runScript = async () => {
    try {
      const response = await axios.get('http://localhost:8000/run-script-comp/');
      setOutput(response.data.output);
      setShowOutput(true);  
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
     {showOutput ? (
        <pre>OUTPUT: {output}</pre>
      ) : (
        <button type="button" class="btn btn-primary" onClick={runScript}>Predict</button>
      )}
    </div>
  );
};

export default ScriptOutput2;