import { useState, useContext } from "react";
import Container from "react-bootstrap/esm/Container";
import AuthContext from "../context/AuthContext";

function Register() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const { registerUser } = useContext(AuthContext);

  const handleSubmit = async e => {
    e.preventDefault();
    registerUser(username, email, password, password2);
  };

  return (
    <Container>
      <form onSubmit={handleSubmit}>
        <h1 style={{color:"white"}}>Register</h1>
        <hr />
        <div class="form-group">
          <label for="username" style={{color:"white"}}>Username</label>
          <input
            type="text"
            id="username"
            class="form-control"
            onChange={e => setUsername(e.target.value)}
            placeholder="Enter Username"
            required
          />
        </div>
        <div>
          <label for="password" style={{color:"white"}}>Password</label>
          <input
            type="password"
            id="password"
            class="form-control"
            onChange={e => setPassword(e.target.value)}
            placeholder="Password"
            required
          />
        </div>
        <div>
          <label for="confirm-password" style={{color:"white"}}>Confirm Password</label>
          <input
            type="password"
            id="confirm-password"
            class="form-control"
            onChange={e => setPassword2(e.target.value)}
            placeholder="Confirm Password"
            required
          />
          <p>{password2 !== password ? "Passwords do not match" : ""}</p>
        </div>
        <div class="form-check">
          <input 
            type="checkbox" 
            class="form-check-input" 
            id="exampleCheck1"
            required
          />
          <label class="form-check-label" for="exampleCheck1" style={{color:"white"}}>Check me out</label>
          </div>
        <button type="submit" class="btn btn-primary">Register</button>
      </form>
      <hr/>
    </Container>
  );
}

export default Register;