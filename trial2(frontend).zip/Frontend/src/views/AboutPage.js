import { useContext } from "react";
import Container from "react-bootstrap/esm/Container";
import AuthContext from "../context/AuthContext";
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import CardGroup from 'react-bootstrap/CardGroup';
import Nav from 'react-bootstrap/Nav';

const AboutPage = () => {
    const { user } = useContext(AuthContext);
    return (
      <>
      {[
        'Dark',
      ].map((variant) => (
      <Container>
      <section style={{textAlign: "center",
      marginTop: "10px" }}>
        <hr/>
        <h1 style={{color:"white"}}>What exactly are we doing?</h1>
        <hr/>
      </section>
      <CardGroup>
            <div>
              <img src="./assets/schezo2.png" height={350} width={550}>
              </img>
            </div>
        <Card
          bg={variant.toLowerCase()}
          key={variant}
          text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
          style={{ width: '18rem' }}
          className="text-center"
        >
          <Card.Body>
          <Card.Title> Spiking Neural Network </Card.Title>
          <br />
          <br />
            <div>
            <Card.Text>
            Spiking neural networks (SNNs) are artificial neural networks that more closely mimic natural neural networks.
            In addition to neuronal and synaptic state, SNNs incorporate the concept of time into their operating model. 
            The idea is that neurons in the SNN do not transmit information at each propagation cycle 
            (as it happens with typical multi-layer perceptron networks), but rather transmit information 
            only when a membrane potential – an intrinsic quality of the neuron related to its membrane electrical charge 
            – reaches a specific value, called the threshold.
            </Card.Text>
            </div>
          </Card.Body>
        </Card>
        </CardGroup>
        <br />
        <CardGroup>
        <Card
          bg={variant.toLowerCase()}
          key={variant}
          text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
          style={{ width: '18rem' }}
          className="text-center"
        >
          <Card.Body>
            <Card.Title> Schezophrenia </Card.Title>
            <br />
            <br />
            <Card.Text>
            Schizophrenia is a serious mental disorder in which people interpret reality abnormally. 
            Schizophrenia may result in some combination of hallucinations, delusions, and extremely disordered 
            thinking and behavior that impairs daily functioning, and can be disabling. People with schizophrenia
             require lifelong treatment.
            </Card.Text>
          </Card.Body>
        </Card>
        <div>
              <img src="./assets/schezo4.png" height={350} width={550}>
              </img>
            </div>
        </CardGroup>
        <br />
        <CardGroup>
        <div>
              <img src="./assets/schezo5.png" height={250} width={500}>
              </img>
            </div>
        <Card
          bg={variant.toLowerCase()}
          key={variant}
          text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
          style={{ width: '18rem' }}
          className="text-center"
        >
          <Card.Body>
            <Card.Title> Metrics </Card.Title>
            <br />
            <br />
            <Card.Text>
            The Accuracy metrics of our model
            </Card.Text>
          </Card.Body>
        </Card>
        </CardGroup>
        <br />
      </Container>
      ))}
      </>
      );
    };
      
    
  
  
  export default AboutPage;