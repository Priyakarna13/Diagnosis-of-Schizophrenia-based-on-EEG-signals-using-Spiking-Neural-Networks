import { useEffect, useState } from "react";
import useAxios from "../utils/useAxios";
import { useContext } from "react";
import Container from "react-bootstrap/esm/Container";
import AuthContext from "../context/AuthContext";
import Upload from "../components/runPy1";
import App from "../components/uploaddemfile";
import App2 from "../components/uploadeegcompfile";
import CardGroup from 'react-bootstrap/CardGroup';

function PredictingPage() {
  const { user } = useContext(AuthContext);
  const [res, setRes] = useState("");
  const api = useAxios();

  //useEffect(() => {
    //const fetchData = async () => {
    //  try {
      //  const response = await api.get("/test/");
        //setRes(response.data.response);
     // } catch {
      //  setRes("Something went wrong");
      //}
    //};
    //fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  //}, []);

  return (
    <Container>
    <section style={{textAlign: "center"}}>
        <hr/>
      <h1 style={{color:"white"}}>Prediction of Schezophrenia with EEG components data</h1>
      <hr/>
      <App2></App2>
      <br/>
      <br/>
      <br/>
      <Upload></Upload>
      <br/>
      <br/>
    </section>
    </Container>
  );
}

export default PredictingPage;