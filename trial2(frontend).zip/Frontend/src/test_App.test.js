import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import App from './App';

describe('App', () => {
  test('renders Navbar component', () => {
    render(
      <Router>
        <App />
      </Router>
    );

    const navbarElement = screen.getByRole('navigation');
    expect(navbarElement).toBeInTheDocument();
  });

  test('renders home page by default', () => {
    render(
      <Router>
        <App />
      </Router>
    );

    const homePageElement = screen.getByText('Home Page');
    expect(homePageElement).toBeInTheDocument();
  });

  test('renders login page when path is /login', () => {
    render(
      <Router initialEntries={['/login']}>
        <App />
      </Router>
    );

    const loginPageElement = screen.getByText('Login Page');
    expect(loginPageElement).toBeInTheDocument();
  });

  test('renders register page when path is /register', () => {
    render(
      <Router initialEntries={['/register']}>
        <App />
      </Router>
    );

    const registerPageElement = screen.getByText('Register Page');
    expect(registerPageElement).toBeInTheDocument();
  });

  // Add more tests for other routes and components
});
