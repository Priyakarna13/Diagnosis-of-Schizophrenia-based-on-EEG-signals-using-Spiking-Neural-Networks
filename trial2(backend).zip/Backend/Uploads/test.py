import ERP_Components_prediction

print(ERP_Components_prediction.predict('D:\\Documents\\FYP\\trial2(backend)\\Uploads\\EEG_Components_1.csv'))