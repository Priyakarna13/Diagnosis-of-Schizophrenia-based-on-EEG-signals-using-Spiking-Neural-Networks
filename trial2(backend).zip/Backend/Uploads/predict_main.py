import predict_erp

Result  = predict_erp.predict('D:\\Documents\\FYP\\trial2(backend)\\Uploads\\EEG_Data.csv', 'D:\\Documents\\FYP\\trial2(backend)\\Uploads\\demographics.csv')