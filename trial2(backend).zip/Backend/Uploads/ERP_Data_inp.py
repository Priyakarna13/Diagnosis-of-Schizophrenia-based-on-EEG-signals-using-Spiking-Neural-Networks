import ERP_Data_plot

Result  = ERP_Data_plot.predict('D:\\Documents\\FYP\\trial2(backend)\\Uploads\\EEG_Data.csv')